this is an arabic lang application used to enroll students into course so they would be able to see what materials instructor share 
also instructor would be able to delete files,count number of files downloaded , or view  enroled students into course, and upload new filesby  feature of multiple files uploaded  with open extension and size of files
2- student have permission to view or download files uploaded by instructor only
this appliction used in arabic lang; also use mysql as database.
copyrights only for  heba mohamed karim Eldin
appliction could be depvoleped so it would able to upload assignments solution  from students
To get database email the devolper. 
